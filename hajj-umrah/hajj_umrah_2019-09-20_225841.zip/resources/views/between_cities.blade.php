{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('wakeel_name', 'Wakeel_name:') !!}
			{!! Form::text('wakeel_name') !!}
		</li>
		<li>
			{!! Form::label('pilgram_count', 'Pilgram_count:') !!}
			{!! Form::text('pilgram_count') !!}
		</li>
		<li>
			{!! Form::label('nationality', 'Nationality:') !!}
			{!! Form::text('nationality') !!}
		</li>
		<li>
			{!! Form::label('hotel', 'Hotel:') !!}
			{!! Form::text('hotel') !!}
		</li>
		<li>
			{!! Form::label('direction_id', 'Direction_id:') !!}
			{!! Form::text('direction_id') !!}
		</li>
		<li>
			{!! Form::label('move_time', 'Move_time:') !!}
			{!! Form::text('move_time') !!}
		</li>
		<li>
			{!! Form::label('move_date', 'Move_date:') !!}
			{!! Form::text('move_date') !!}
		</li>
		<li>
			{!! Form::label('journey_number', 'Journey_number:') !!}
			{!! Form::text('journey_number') !!}
		</li>
		<li>
			{!! Form::label('advance_standby', 'Advance_standby:') !!}
			{!! Form::text('advance_standby') !!}
		</li>
		<li>
			{!! Form::label('day', 'Day:') !!}
			{!! Form::text('day') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}