{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('name', 'Name:') !!}
			{!! Form::text('name') !!}
		</li>
		<li>
			{!! Form::label('phone', 'Phone:') !!}
			{!! Form::text('phone') !!}
		</li>
		<li>
			{!! Form::label('recipient', 'Recipient:') !!}
			{!! Form::text('recipient') !!}
		</li>
		<li>
			{!! Form::label('terminator', 'Terminator:') !!}
			{!! Form::text('terminator') !!}
		</li>
		<li>
			{!! Form::label('wakeel_id', 'Wakeel_id:') !!}
			{!! Form::text('wakeel_id') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}