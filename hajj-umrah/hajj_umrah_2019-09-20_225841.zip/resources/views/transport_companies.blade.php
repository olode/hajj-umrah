{!! Form::open(array('route' => 'route.name', 'method' => 'POST')) !!}
	<ul>
		<li>
			{!! Form::label('name', 'Name:') !!}
			{!! Form::text('name') !!}
		</li>
		<li>
			{!! Form::label('phone', 'Phone:') !!}
			{!! Form::text('phone') !!}
		</li>
		<li>
			{!! Form::label('driver_name', 'Driver_name:') !!}
			{!! Form::text('driver_name') !!}
		</li>
		<li>
			{!! Form::label('driver_id', 'Driver_id:') !!}
			{!! Form::text('driver_id') !!}
		</li>
		<li>
			{!! Form::label('car_plate', 'Car_plate:') !!}
			{!! Form::text('car_plate') !!}
		</li>
		<li>
			{!! Form::label('wakeel_id', 'Wakeel_id:') !!}
			{!! Form::text('wakeel_id') !!}
		</li>
		<li>
			{!! Form::submit() !!}
		</li>
	</ul>
{!! Form::close() !!}